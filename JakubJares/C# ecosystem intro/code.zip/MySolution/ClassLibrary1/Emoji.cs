﻿namespace ClassLibrary1
{
    public class Emoji
    {
        public string Name { get; set; }  // Avocado
        public string Glyph { get; set; } // 🥑
    }
}
