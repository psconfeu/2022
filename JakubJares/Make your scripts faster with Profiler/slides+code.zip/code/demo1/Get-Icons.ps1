Import-Module $PSScriptRoot\Avocado.psm1 -Force

function Get-Icons () { 
    Get-Avocado
    Get-Unicorn
}

Get-Icons