
function Push-State {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false)]
        [AllowNull()]
        [pscustomobject]
        $State
    )
    if (-Not $script:_ASowflake_State) {
        $script:_ASowflake_State = @()
    }
    $currentState = $(Get-State)
    Write-Verbose "Push-State: pushing..."
    if ($VerbosePreference -ne 'SilentlyContinue') {
        $currentState | ConvertTo-Json -Depth 2 | Write-Verbose
    }
    $new_ASowflake_State = @($currentState) + $script:_ASowflake_State
    $script:_ASowflake_State = $new_ASowflake_State
    if ($State) {
        Write-Verbose "Push-State: setting..."
        Set-State -State $State
    }
}

function Pop-State {
    [CmdletBinding()]
    param(
        [switch]
        $PassThru
    )
    if (-Not $script:_ASowflake_State) {
        return
    }
    $state, $rest = $script:_ASowflake_State
    $script:_ASowflake_State = $rest
    Write-Verbose "Pop-State: setting..."
    if ($VerbosePreference -ne 'SilentlyContinue') {
        $state | ConvertTo-Json -Depth 2 | Write-Verbose
    }
    Set-State -State $state
    if ($PassThru) {
        $state
    }
}

function Get-State {
    [CmdletBinding()]
    param()
    @{
        Services   = @($(Get-Service))
        Chocolatey = @($(Get-ChildItem "${env:ChocolateyInstall}/lib/*/*.nuspec") | Foreach-Object {
                [xml]$nuspec = Get-Content $_.FullName
                @{
                    id      = $nuspec.package.metadata.id
                    version = $nuspec.package.metadata.version
                }
            })
    }
}

function Set-State {
    [CmdletBinding()]
    param(
        [pscustomobject]
        $State
    )
    Write-Verbose "Set-State: getting current (compare) state..."
    $currentState = Get-State
    Write-Verbose $currentState
    Write-Verbose "Set-State: setting state..."

    $State.Chocolatey | Foreach-Object {
        $packageId = $_.id
        $cp = $currentState.Chocolatey | Where-Object { $_.id -eq $packageId }
        Restore-ChocoState -wanted $_ -given $cp
    }
    # explicitly delete new stuff
    $currentState.Chocolatey | Where-Object { $_.id -notin $State.Chocolatey.id } | Foreach-Object {
        Restore-ChocoState -wanted $null -given $_
    }

    $State.Services | Foreach-Object {
        $svName = $_.Name
        $cs = $currentState.Services | Where-Object { $_.Name -eq $svName }
        Restore-ServiceState -wanted $_ -given $cs
    }
    # explicitly delete new stuff
    $currentState.Services | Where-Object { $_.Name -notin $State.Services.Name } | Foreach-Object {
        Restore-Services -wanted $null -given $_
    }
}

Export-ModuleMember -Function @('Push-State', 'Set-State', 'Get-State', 'Pop-State')


# ----------------------------------------------------------------------------------------------------------------------
# module entrails that are not publicly exported down here
# ----------------------------------------------------------------------------------------------------------------------

function Restore-ServiceState {
    [CmdletBinding()]
    param ($wanted, $given)
    # BinaryPathName etc. - see $svc | Get-Member
    if (-Not $wanted) {
        Write-Host "service '$($given.new)' is new - *UN*INSTALL!"
        Remove-Service $given; return
    }
    if (-Not $given) {
        Write-Host "service '$($given.new)' is missing - RESTORE!"
        # TODO: ... recover/restore service from old info!
        return;
    }
    if ($wanted.Status -ne $given.Status) {
        Write-Host "service '$($wanted.Name)' wanted state '$($wanted.Status)' but got '$($given.Status)'"
        switch ($wanted.Status) {
            "Running" {
                Start-Service $given
            }
            "Stopped" {
                Stop-Service $given -Force
            }
        }
    }
    else {
        Write-Verbose "service '$($wanted.Name)' is already in state '$($wanted.Status)'"
    }
}

function Restore-ChocoState {
    [CmdletBinding()]
    param ($wanted, $given)
    if (-Not $wanted) {
        Write-Host "package '$($given.id)' is new - *UN*INSTALL!"
        choco uninstall $given.id -yf | Write-Host
        return
    }
    if (-Not $given) {
        Write-Host "package '$($wanted.id)' wanted version '$($wanted.version)' not present - INSTALL!"
        choco install $wanted.id --version $wanted.version -yf | Write-Host
        return
    }
    if ($wanted.version -ne $given.version) {
        Write-Host "package '$($wanted.id)' wanted version '$($wanted.version)' but got '$($given.version)'"
        choco install $wanted.id --version $wanted.version -yf | Write-Host
    }
    else {
        Write-Verbose "package '$($wanted.id)' already installed in correct version '$($wanted.version)'"
    }
}
