
$BuildRoot = Join-Path $PSScriptRoot "antlr"

$grammarFile = "Infracheck.g4"
$antlrOut = "infraparser"

Task Clean {
    Remove-Item -Path $antlrOut -Recurse -ErrorAction SilentlyContinue | Out-Null
}

Task GenerateJavaFiles {
    Exec {
        antlr4 $grammarFile -o "$antlrOut"
    }
}

Task CompileJavaFiles {
    Set-Location (Join-Path $BuildRoot $antlrOut)
    Exec {
        javac -cp /usr/share/java/antlr-complete.jar ./Infracheck*.java
    }
}

Task Build GenerateJavaFiles,CompileJavaFiles

Task Test {
    Import-Module Pester
    Invoke-Pester -Path ./demo04-antlr.Tests.ps1 -Output Detailed
}
