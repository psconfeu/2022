// Generated from /home/mw/git/psconf-2022/ManfredWallner/Demystifying PowerShell DSLs/demo/antlr/Infracheck.g4 by ANTLR 4.9.2
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public class InfracheckParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.9.2", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		T__0=1, T__1=2, T__2=3, T__3=4, SQ=5, QTEXT=6, NUMBER=7, DIGIT=8, HOST=9, 
		SERVICES=10, CHOCO=11, TIMEOUT=12, REMOTEUSER=13, WHITESPACE=14;
	public static final int
		RULE_toplevel = 0, RULE_hostdef = 1, RULE_body = 2, RULE_hostspec = 3, 
		RULE_remoteuserspec = 4, RULE_timeoutspec = 5, RULE_servicespec = 6, RULE_chocospec = 7, 
		RULE_qtextlist = 8;
	private static String[] makeRuleNames() {
		return new String[] {
			"toplevel", "hostdef", "body", "hostspec", "remoteuserspec", "timeoutspec", 
			"servicespec", "chocospec", "qtextlist"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, "'{'", "'}'", "';'", "','", "'''", null, null, null, "'Host'", 
			"'Services'", "'Chocolatey'", "'Timeout'", "'RemoteUser'"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, null, null, null, null, "SQ", "QTEXT", "NUMBER", "DIGIT", "HOST", 
			"SERVICES", "CHOCO", "TIMEOUT", "REMOTEUSER", "WHITESPACE"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "Infracheck.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public InfracheckParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	public static class ToplevelContext extends ParserRuleContext {
		public HostdefContext hostdef() {
			return getRuleContext(HostdefContext.class,0);
		}
		public RemoteuserspecContext remoteuserspec() {
			return getRuleContext(RemoteuserspecContext.class,0);
		}
		public ToplevelContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_toplevel; }
	}

	public final ToplevelContext toplevel() throws RecognitionException {
		ToplevelContext _localctx = new ToplevelContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_toplevel);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(19);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==REMOTEUSER) {
				{
				setState(18);
				remoteuserspec();
				}
			}

			setState(21);
			hostdef();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class HostdefContext extends ParserRuleContext {
		public TerminalNode HOST() { return getToken(InfracheckParser.HOST, 0); }
		public TerminalNode QTEXT() { return getToken(InfracheckParser.QTEXT, 0); }
		public BodyContext body() {
			return getRuleContext(BodyContext.class,0);
		}
		public HostdefContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_hostdef; }
	}

	public final HostdefContext hostdef() throws RecognitionException {
		HostdefContext _localctx = new HostdefContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_hostdef);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(23);
			match(HOST);
			setState(24);
			match(QTEXT);
			setState(26);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==T__0) {
				{
				setState(25);
				body();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class BodyContext extends ParserRuleContext {
		public HostspecContext hostspec() {
			return getRuleContext(HostspecContext.class,0);
		}
		public BodyContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_body; }
	}

	public final BodyContext body() throws RecognitionException {
		BodyContext _localctx = new BodyContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_body);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(28);
			match(T__0);
			setState(29);
			hostspec();
			setState(30);
			match(T__1);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class HostspecContext extends ParserRuleContext {
		public RemoteuserspecContext remoteuserspec() {
			return getRuleContext(RemoteuserspecContext.class,0);
		}
		public TimeoutspecContext timeoutspec() {
			return getRuleContext(TimeoutspecContext.class,0);
		}
		public List<ServicespecContext> servicespec() {
			return getRuleContexts(ServicespecContext.class);
		}
		public ServicespecContext servicespec(int i) {
			return getRuleContext(ServicespecContext.class,i);
		}
		public List<ChocospecContext> chocospec() {
			return getRuleContexts(ChocospecContext.class);
		}
		public ChocospecContext chocospec(int i) {
			return getRuleContext(ChocospecContext.class,i);
		}
		public HostspecContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_hostspec; }
	}

	public final HostspecContext hostspec() throws RecognitionException {
		HostspecContext _localctx = new HostspecContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_hostspec);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(33);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==REMOTEUSER) {
				{
				setState(32);
				remoteuserspec();
				}
			}

			setState(36);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==TIMEOUT) {
				{
				setState(35);
				timeoutspec();
				}
			}

			setState(42);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==SERVICES || _la==CHOCO) {
				{
				setState(40);
				_errHandler.sync(this);
				switch (_input.LA(1)) {
				case SERVICES:
					{
					setState(38);
					servicespec();
					}
					break;
				case CHOCO:
					{
					setState(39);
					chocospec();
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				}
				setState(44);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class RemoteuserspecContext extends ParserRuleContext {
		public TerminalNode REMOTEUSER() { return getToken(InfracheckParser.REMOTEUSER, 0); }
		public TerminalNode QTEXT() { return getToken(InfracheckParser.QTEXT, 0); }
		public RemoteuserspecContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_remoteuserspec; }
	}

	public final RemoteuserspecContext remoteuserspec() throws RecognitionException {
		RemoteuserspecContext _localctx = new RemoteuserspecContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_remoteuserspec);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(45);
			match(REMOTEUSER);
			setState(46);
			match(QTEXT);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class TimeoutspecContext extends ParserRuleContext {
		public TerminalNode TIMEOUT() { return getToken(InfracheckParser.TIMEOUT, 0); }
		public TerminalNode NUMBER() { return getToken(InfracheckParser.NUMBER, 0); }
		public TimeoutspecContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_timeoutspec; }
	}

	public final TimeoutspecContext timeoutspec() throws RecognitionException {
		TimeoutspecContext _localctx = new TimeoutspecContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_timeoutspec);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(48);
			match(TIMEOUT);
			setState(49);
			match(NUMBER);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ServicespecContext extends ParserRuleContext {
		public TerminalNode SERVICES() { return getToken(InfracheckParser.SERVICES, 0); }
		public QtextlistContext qtextlist() {
			return getRuleContext(QtextlistContext.class,0);
		}
		public ServicespecContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_servicespec; }
	}

	public final ServicespecContext servicespec() throws RecognitionException {
		ServicespecContext _localctx = new ServicespecContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_servicespec);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(51);
			match(SERVICES);
			setState(52);
			qtextlist();
			setState(53);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ChocospecContext extends ParserRuleContext {
		public TerminalNode CHOCO() { return getToken(InfracheckParser.CHOCO, 0); }
		public QtextlistContext qtextlist() {
			return getRuleContext(QtextlistContext.class,0);
		}
		public ChocospecContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_chocospec; }
	}

	public final ChocospecContext chocospec() throws RecognitionException {
		ChocospecContext _localctx = new ChocospecContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_chocospec);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(55);
			match(CHOCO);
			setState(56);
			qtextlist();
			setState(57);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class QtextlistContext extends ParserRuleContext {
		public List<TerminalNode> QTEXT() { return getTokens(InfracheckParser.QTEXT); }
		public TerminalNode QTEXT(int i) {
			return getToken(InfracheckParser.QTEXT, i);
		}
		public QtextlistContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_qtextlist; }
	}

	public final QtextlistContext qtextlist() throws RecognitionException {
		QtextlistContext _localctx = new QtextlistContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_qtextlist);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(59);
			match(QTEXT);
			setState(64);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__3) {
				{
				{
				setState(60);
				match(T__3);
				setState(61);
				match(QTEXT);
				}
				}
				setState(66);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static final String _serializedATN =
		"\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\3\20F\4\2\t\2\4\3\t"+
		"\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7\4\b\t\b\4\t\t\t\4\n\t\n\3\2\5\2\26"+
		"\n\2\3\2\3\2\3\3\3\3\3\3\5\3\35\n\3\3\4\3\4\3\4\3\4\3\5\5\5$\n\5\3\5\5"+
		"\5\'\n\5\3\5\3\5\7\5+\n\5\f\5\16\5.\13\5\3\6\3\6\3\6\3\7\3\7\3\7\3\b\3"+
		"\b\3\b\3\b\3\t\3\t\3\t\3\t\3\n\3\n\3\n\7\nA\n\n\f\n\16\nD\13\n\3\n\2\2"+
		"\13\2\4\6\b\n\f\16\20\22\2\2\2C\2\25\3\2\2\2\4\31\3\2\2\2\6\36\3\2\2\2"+
		"\b#\3\2\2\2\n/\3\2\2\2\f\62\3\2\2\2\16\65\3\2\2\2\209\3\2\2\2\22=\3\2"+
		"\2\2\24\26\5\n\6\2\25\24\3\2\2\2\25\26\3\2\2\2\26\27\3\2\2\2\27\30\5\4"+
		"\3\2\30\3\3\2\2\2\31\32\7\13\2\2\32\34\7\b\2\2\33\35\5\6\4\2\34\33\3\2"+
		"\2\2\34\35\3\2\2\2\35\5\3\2\2\2\36\37\7\3\2\2\37 \5\b\5\2 !\7\4\2\2!\7"+
		"\3\2\2\2\"$\5\n\6\2#\"\3\2\2\2#$\3\2\2\2$&\3\2\2\2%\'\5\f\7\2&%\3\2\2"+
		"\2&\'\3\2\2\2\',\3\2\2\2(+\5\16\b\2)+\5\20\t\2*(\3\2\2\2*)\3\2\2\2+.\3"+
		"\2\2\2,*\3\2\2\2,-\3\2\2\2-\t\3\2\2\2.,\3\2\2\2/\60\7\17\2\2\60\61\7\b"+
		"\2\2\61\13\3\2\2\2\62\63\7\16\2\2\63\64\7\t\2\2\64\r\3\2\2\2\65\66\7\f"+
		"\2\2\66\67\5\22\n\2\678\7\5\2\28\17\3\2\2\29:\7\r\2\2:;\5\22\n\2;<\7\5"+
		"\2\2<\21\3\2\2\2=B\7\b\2\2>?\7\6\2\2?A\7\b\2\2@>\3\2\2\2AD\3\2\2\2B@\3"+
		"\2\2\2BC\3\2\2\2C\23\3\2\2\2DB\3\2\2\2\t\25\34#&*,B";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}