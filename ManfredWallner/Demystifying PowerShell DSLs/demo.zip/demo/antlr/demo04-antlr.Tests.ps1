
Describe "validate sample grammar files" {

    BeforeAll {
        Push-Location "infraparser"
    }

    AfterAll {
        Pop-Location
    }

    It "successfully parses all valid files" {
        Get-ChildItem "../grammartests/*.valid.infradef" | ForEach-Object {
            Write-Host "check valid: $($_.Name)"
            $r = (grun Infracheck toplevel $_.FullName 2>&1)
            $r | Should -BeNullOrEmpty
            $LASTEXITCODE | Should -Be 0
        }
    }

    It "fails to parse invalid grammar" {
        Get-ChildItem "../grammartests/*.invalid.infradef" | ForEach-Object {
            Write-Host "check invalid: $($_.Name)"
            $r = (grun Infracheck toplevel $_.FullName 2>&1)
            $r | Should -Not -BeNullOrEmpty
            $LASTEXITCODE | Should -Be 0
        }
    }

}
