# just to be sure
Remove-Module -Name Pester -ErrorAction SilentlyContinue
Remove-Module -Name infracheck -ErrorAction SilentlyContinue
Remove-Module -Name demo* -ErrorAction SilentlyContinue

Import-Module (Join-Path $PSScriptRoot 'infracheck.psm1')

Invoke-Infracheck -File ./demo06.infradef.bad.ps1 -Passthru
#Invoke-Infracheck -File ./demo06.infradef.ps1 -Passthru
