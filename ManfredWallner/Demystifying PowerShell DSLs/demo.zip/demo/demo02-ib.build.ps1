
Task . Clean, Build, Test

# NOTE: Enter-Build is neccessary for additional functionality i.e. to print a dependency tree
#Enter-Build {
$buildDir = Join-Path $PSScriptRoot "_build_out"
$srcFile = 'main.c'
$binFile = 'Main'
#}

Task Clean {
    Remove-Item -Path $buildDir -Recurse -Force -ErrorAction SilentlyContinue | Out-Null
    New-Item -ItemType Directory -Path $buildDir -Force | Out-Null
}

Task Build {
    # NOTE: '$BuildRoot = ...' (try {} finally { Pop-Location })
    Set-Location $buildDir
    "int main() { return 42; }" | Out-File -FilePath $srcFile
    Exec {
        gcc $srcFile -o"$binFile" -Wall
    }
    if (-Not (Test-Path $binFile)) {
        throw "expected output file not present!"
    }
}

Task Test Build, {
    Set-Location $buildDir
    # no Exec{} here -> exit code is 42
    & "./$binFile"
    if ($LASTEXITCODE -ne 42) {
        throw 'unexpected answer'
    }
}

Task . Clean,Build,Test
