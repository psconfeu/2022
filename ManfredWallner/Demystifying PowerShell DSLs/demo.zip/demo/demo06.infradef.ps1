
RemoteUser 'flynn'

Host 'adctl01.myorg.dev' {
    Timeout 2
    Services 'Winmgmt', 'LanmanServer';
    Chocolatey 'KB2919355', 'KB2999226', 'KB3118401', 'pwsh', 'ripgrep', 'vim';
}

Host 'jenkins-root.myorg.dev' {
    Services 'Winmgmt', 'Dnscache';
    Chocolatey 'pwsh', 'ripgrep', 'git';
}

