
Describe "check basic environment details" {

    Context "user specific" {

        It "is not flynn" {
            $env:USERNAME | Should -Not -Be "flynn"
        }

        It "is mw" {
            $env:USERNAME | Should -Be "mw"
        }
    }

    Context "powershell specific" {

        It "has at least powershell v7" {
            $PSVersionTable.PSVersion | Should -Match "^7\.+"
        }

        It "runs on supported OS variant" {
            $PSVersionTable.OS | Should -Match "Linux"
        }

    }

}


Describe "math does it's thing" {

    BeforeAll {
        function inc($val) {
            $val + 1
        }
    }

    It "verifies induction is ok" {
        inc(1) | Should -Be 2
        inc(inc(1)) | Should -Be $(inc(2))
    }

}

