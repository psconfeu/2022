#requires -Version 7.2
#requires -Modules @{ ModuleName = 'Pester'; MaximumVersion = '4.10.0' }
# Install-Module -Name Pester -RequiredVersion 4.10.0

<#
see Infracheck.g4

 - HOST: 'Host' => function Host ...
 - SERVICES: 'Services';
 - CHOCO: 'Chocolatey';
#>

function RemoteUser {
    param(
        [Parameter(Mandatory, Position = 0)]
        [string]
        $UserName
    )
    $script:t_ica_u = $UserName
}

function Services {
    param(
        [Parameter(Mandatory, Position = 0)]
        [string[]]
        $Services
    )
    Context 'Services' {
        $allServices = Invoke-Command @script:t_ica -ScriptBlock { Get-Service }
        $Services | Foreach-Object {
            $svcName = $_
            Write-Verbose "check service $svcName "
            It "has service '$svcName' installed and running" {
                $s = $allServices | Where-Object { $_.Name -eq $svcName }
                $s | Should -Not -BeNullOrEmpty
                $s.Status | Should -Be "Running"
            }
        }
    }
}

function Chocolatey {
    param(
        [Parameter(Mandatory, Position = 0)]
        [string[]]
        $Packages
    )
    Context 'Chocolatey' {
        It "has no packages in lib-bad" {
            Invoke-Command @script:t_ica -ScriptBlock {
          (Get-ChildItem "${env:ChocolateyInstall}\lib-bad").Count
            } | Should -Be 0
        }
        $allPkgs = Invoke-Command @script:t_ica -ScriptBlock {
        (Get-ChildItem "${env:ChocolateyInstall}\lib").Name
        }
        $Packages | Foreach-Object {
            Write-Verbose "check choco pkg $_ "
            It "has chocolatey package '$_' installed" {
                $_ | Should -BeIn $allPkgs
            }
        }
    }
}


function Host {
    param(
        [Parameter(Mandatory, Position = 0)]
        [Alias("HostName")]
        [string]
        $ComputerName,

        [Parameter(Mandatory = $false, Position = 1)]
        [scriptblock]
        $ScriptBlock
    )

    function Set-RemoteConnectionDetails {
        param(
            [string]
            $ComputerName
        )
        $script:t_ica = if ($PSVersionTable.Platform -eq 'Unix') {
            # using ssh / keyfiles
            @{
                HostName = $ComputerName
                Username = $t_ica_u
            }
        }
        else {
            # using winrm / clixml
            @{
                ComputerName = $ComputerName
                Credential   = Get-StoredCredential $ComputerName
            }
        }
    }

    Describe "Host '$ComputerName'" {
        Set-RemoteConnectionDetails -ComputerName $ComputerName
        It "is active" {
            $pRes = Test-Connection -Ping -TimeoutSeconds 1 -Count 1 -TargetName $ComputerName -BufferSize 1500
            $pres.Status | Should -Be 'Success'
        }
        if ($ScriptBlock) {
            & $ScriptBlock
        }
    }
}


Export-ModuleMember -Function @('RemoteUser', 'Host', 'Services', 'Chocolatey')
