#requires -Version 7.2
#requires -Modules @{ ModuleName = 'Pester'; MaximumVersion = '4.10.0' }

function RemoteUser {
    param(
        [Parameter(Mandatory, Position = 0)]
        [string]
        $UserName
    )
    $script:t_ica_u = $UserName
}

function Timeout {
    param(
        [Parameter(Mandatory, Position = 0)]
        [int32]
        $Timeout
    )
    $script:t_ica_to = $Timeout
}

function Services {
    param(
        [Parameter(Mandatory, Position = 0)]
        [string[]]
        $Services
    )
    Context 'Services' {
        $allServices = Invoke-Command @script:t_ica -ScriptBlock { Get-Service }
        $Services | Foreach-Object {
            $svcName = $_
            Write-Verbose "check service $svcName "
            It "$svcName" {
                $s = $allServices | Where-Object { $_.Name -eq $svcName }
                $s | Should -Not -BeNullOrEmpty
                $s.Status | Should -Be "Running"
            }
        }
    }
}

function Chocolatey {
    param(
        [Parameter(Mandatory, Position = 0)]
        [string[]]
        $Packages
    )
    Context 'Chocolatey' {
        It "cleanLibBad" {
            Invoke-Command @script:t_ica -ScriptBlock {
          (Get-ChildItem "${env:ChocolateyInstall}\lib-bad").Count
            } | Should -Be 0
        }
        $allPkgs = Invoke-Command @script:t_ica -ScriptBlock {
        (Get-ChildItem "${env:ChocolateyInstall}\lib").Name
        }
        $Packages | Foreach-Object {
            Write-Verbose "check choco pkg $_ "
            It "$_" {
                $_ | Should -BeIn $allPkgs
            }
        }
    }
}

function Host {
    param(
        [Parameter(Mandatory, Position = 0)]
        [Alias("HostName")]
        [string]
        $ComputerName,

        [Parameter(Mandatory = $false, Position = 1)]
        [scriptblock]
        $ScriptBlock
    )

    function Set-RemoteConnectionDetails {
        param(
            [string]
            $ComputerName
        )
        $script:t_ica = if ($PSVersionTable.Platform -eq 'Unix') {
            # using ssh / keyfiles
            @{
                HostName = $ComputerName
                Username = $t_ica_u
            }
        }
        else {
            # using winrm / clixml
            @{
                ComputerName = $ComputerName
                Credential   = Get-StoredCredential $ComputerName
            }
        }
    }

    Describe "$ComputerName" {
        Set-RemoteConnectionDetails -ComputerName $ComputerName
        It "isActive" {
            $TimeoutSeconds = if ($script:t_ica_to) { $script:t_ica_to } else { 1 }
            $pRes = Test-Connection -Ping -TimeoutSeconds $TimeoutSeconds -Count 1 -TargetName $ComputerName -BufferSize 1500
            $pres.Status | Should -Be 'Success'
        }
        if ($ScriptBlock) {
            & $ScriptBlock
        }
    }
}

function Invoke-Infracheck {
    param(
        [string]
        $File,

        [switch]
        $PassThru
    )
    $ErrorActionPreference = 'Stop'

    function Test-InfracheckDSLSyntax {
        param(
            [string]
            $File
        )
        $f = Get-Item $File
        Push-Location "$PSScriptRoot\antlr\infraparser"
        try {
            $r = (grun Infracheck toplevel $f.FullName 2>&1)
            if ($r -Or ($LASTEXITCODE -ne 0)) {
                Write-Host $r -ForegroundColor Red
                throw "failed to validate syntax of '$File'"
            }
            Write-Host " ==> SYNTAX OK <== "
        }
        finally {
            Pop-Location
        }
    }
    # will throw if there's a syntax error
    Test-InfracheckDSLSyntax -File $File


    Invoke-Pester (Get-Item $File).FullName -PassThru:$Passthru
}

Export-ModuleMember -Function @('RemoteUser', 'Host', 'Services', 'Chocolatey', 'Timeout', 'Invoke-Infracheck')
