
# https://vega.github.io/vega-lite/usage/embed.html

function VegaLiteChart {
    [cmdletbinding()]
    param(
        # scriptblock that should put pester result object on pipeline
        [scriptblock]
        $ScriptBlock
    )
    Write-Verbose ' > VegaLiteChart'
    $script:_VL_MappedTestData = @()
    $script:_VL_chartCounter = 0

    function Get-NextVisID() {
        $script:_VL_chartCounter = $_VL_chartCounter + 1
        "vis$_VL_chartCounter"
    }

    function Test {
        [cmdletbinding()]
        param(
            [scriptblock]
            $ScriptBlock
        )
        Write-Verbose ' > Test'
        $t = & $ScriptBlock
        $script:_VL_MappedTestData += $t.TestResult | ForEach-Object {
            @{
                Describe = $_.Describe
                Context  = $_.Context
                Name     = $_.Name
                Result   = $_.Result
            }
        }
    }

    function BarChart {
        [cmdletbinding()]
        param(
            [scriptblock]
            $ScriptBlock
        )
        $_vId = Get-NextVisID
        Write-Verbose " > BarChart ($_vId)"

        function Title {
            [cmdletbinding()]
            param(
                [string] $Title
            )
            Write-Verbose " > BarChart.Title = $Title"
            $script:_title = $Title
        }

        function Encoding {
            [cmdletbinding()]
            param(
                [hashtable]
                $Encoding
            )
            Write-Verbose " > BarChart.Encoding = $($Encoding | ConvertTo-Json -Compress -Depth 3)"
            $script:_encoding = @{}
            $Encoding.GetEnumerator() | ForEach-Object {
                $script:_encoding[$_.Key] = @{
                    field = $_.Value
                    type  = 'ordinal'
                }
            }
        }

        "<div id='$_vId'>""</div>"
        & $ScriptBlock

        Write-Verbose "_title: $_title"
        $_title = $_title ?? 'bar chart'
        @"
    <script type="text/javascript">
      var vlSpec = {
        `$schema: 'https://vega.github.io/schema/vega-lite/v5.json',
        description: '$_title',
        data: { values: $($_VL_MappedTestData | ConvertTo-Json -Depth 3) },
        mark: 'bar',
        encoding: $($_encoding  | ConvertTo-Json -Depth 3)
      };
      vegaEmbed('#$_vId', vlSpec);
    </script>
"@
    }

    @"
<!DOCTYPE html>
<html>
  <head>
    <title>Pester2Vega</title>
    <script src="./npm/vega@5.21.0.js"></script>
    <script src="./npm/vega-lite@5.2.0.js"></script>
    <script src="./npm/vega-embed@6.20.2.js"></script>
  </head>
  <body>
"@
    & $ScriptBlock
    @"
  </body>
</html>
"@
}


Remove-Module -Name Pester -Force
Import-Module Pester -MaximumVersion '4.10.0'


VegaLiteChart {

    #Test { Invoke-Pester -Path '../demo01-pester.Tests.ps1' -PassThru }
    Test { Invoke-Infracheck -File '../demo06.infradef.ps1' -PassThru }

    BarChart {
        Title 'this is a bar chart'
        Encoding @{
            x     = 'Result'
            y     = 'Name'
            color = 'Result'
        }
    }

    BarChart {
        Title 'this is a bar chart'
        Encoding @{
            x     = 'Describe'
            y     = 'Result'
            color = 'Name'
        }
    }

}
