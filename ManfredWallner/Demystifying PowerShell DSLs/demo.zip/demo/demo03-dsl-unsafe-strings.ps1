
function Host {
    param (
        [string]$hostAddress
    )
    Write-Host "this is '$hostAddress'"
}


Host "ADCtrl002.myorg" {
    Services WinRM
    ...
}

Host "$(((iwr 'https://xkcd.com/info.0.json') | ConvertFrom-Json).safe_title)" {
    Services dang!
}

Host '$(((iwr "https://xkcd.com/info.0.json") | ConvertFrom-Json).safe_title)' {
    Services dang!
}
