# just to be sure
Remove-Module -Name Pester -ErrorAction SilentlyContinue
Remove-Module -Name demo* -ErrorAction SilentlyContinue

# start test VM
if (-Not (virsh list | rg 'win10\s+running')) {
    Write-Host "starting demo vm..."
    virsh start win10 | Write-Host
    Start-Sleep -Seconds 30
}

# import the DSL
Import-Module (Join-Path $PSScriptRoot 'demo05-infradsl-Module.psm1')

# set user that's going to be used when connecting to remote hosts (global)
RemoteUser 'flynn'

Host 'adctl01.myorg.dev' {
    Services 'Winmgmt';
    Chocolatey 'KB2919355', 'KB2999226', 'KB3118401', 'pwsh', 'ripgrep', 'vim';
}

Host 'jenkins-root.myorg.dev'
