﻿$dbsToExclude = @("master", "tempdb", "model", "msdb")
Get-DbaDatabase -SqlInstance localhost -SqlCredential $sqlcred | Select-Object -ExpandProperty name | Where-Object { $dbsToExclude -notcontains $_ } | ForEach-Object {
    Backup-DbaDatabase -SqlInstance localhost -SqlCredential $sqlcred -Database $_ -Path $backupsFolderPath 
}
