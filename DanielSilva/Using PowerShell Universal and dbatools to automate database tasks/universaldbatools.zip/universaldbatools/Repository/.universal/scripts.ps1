﻿New-PSUScript -Name "Backup_northwind.ps1" -Path "Backup_northwind.ps1" -Environment "7.2.1" -InformationAction "Continue" 
New-PSUScript -Name "Latency.ps1" -Description "From time to time, tests network latency" -Path "Latency.ps1" -InformationAction "Continue" 
New-PSUScript -Name "BackupAll.ps1" -Path "BackupAll.ps1" -InformationAction "Continue"