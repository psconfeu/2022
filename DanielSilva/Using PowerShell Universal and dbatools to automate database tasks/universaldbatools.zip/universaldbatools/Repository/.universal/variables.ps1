﻿New-PSUVariable -Name "sqlcred" -Vault "PSUSecretStore" -Type "PSCredential" 
New-PSUVariable -Name "backupsFolderPath" -Value '/backup' 
New-PSUVariable -Name "latencyLogsFolderPath" -Value '/Users/danielsilva/Documents/Presentations/psconfeu22/universaldbatools/latency_logs' 
New-PSUVariable -Name "backupFolderOnHost" -Value '/Users/danielsilva/Documents/Presentations/psconfeu22/universaldbatools/databaseBackups' 
New-PSUVariable -Name "formCookie" -Vault "PSUSecretStore"