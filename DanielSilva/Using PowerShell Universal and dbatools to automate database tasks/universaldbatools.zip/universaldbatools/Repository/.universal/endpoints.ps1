﻿New-PSUEndpoint -Url "/databases" -Description "Get all databases on current instance" -Endpoint {
Get-DbaDatabase -SqlInstance localhost -SqlCredential $sqlcred | Select-Object Name, status, RecoveryModel, SizeMB, LastFullBackup, LastDiffBackup, LastLogBackup
} 
New-PSUEndpoint -Url "/instances" -Description "delete all burstable instances" -Method "DELETE" -Endpoint {
# Enter your script to process requests.
docker ps -a --format "table {{.Names}},{{.Image}},{{.Ports}}" | ConvertFrom-Csv -Delimiter ',' | Where-Object {$_.Names.StartsWith('burstable_sqlinstance')} | Select-Object -ExpandProperty Names | Foreach-Object {docker rm -f $_}
}