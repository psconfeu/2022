﻿New-PSUEnvironment -Name "7.2.1" -Version "7.2.1" -Path "/usr/local/bin/pwsh" -Variables @('*') 
New-PSUEnvironment -Name "Integrated" -Version "7.1.5" -Path "Universal.Server" -Variables @('*')