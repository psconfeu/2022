﻿$datetime = Get-Date
$date = $datetime.ToString("yyyyMMdd")
$logsPath = "$latencyLogsFolderPath/$date.log"
$existingLogs = @()
if (Test-Path $logsPath)
{
    $existingLogs += Get-Content $logsPath | ConvertFrom-Json
}

$avg = Test-DbaNetworkLatency -SqlInstance localhost -SqlCredential $sqlcred | Select-Object -ExpandProperty Average | Select-Object -ExpandProperty Milliseconds


$existingLogs += @{
    "time" = $datetime.ToShortTimeString()
    "average" = $avg
} 

$existingLogs | ConvertTo-Json | Out-File -FilePath "$latencyLogsFolderPath/$date.log"

Write-Host "It took on average $avg ms to ping the instance"