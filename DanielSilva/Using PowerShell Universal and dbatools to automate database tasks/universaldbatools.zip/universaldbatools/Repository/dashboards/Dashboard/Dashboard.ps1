﻿$navigation = New-UDList -Content {
    New-UDListItem -Label "Dashboard" -OnClick { Invoke-UDRedirect '/' } -Icon (New-UDIcon -Icon ChartLine -Size 1x)
    New-UDListItem -Label "Logs" -OnClick { Invoke-UDRedirect '/logs' } -Icon (New-UDIcon -Icon BookOpen -Size 1x)
    New-UDListItem -Label "Management" -OnClick { Invoke-UDRedirect '/management' } -Icon (New-UDIcon -Icon Wrench -Size 1x)
    New-UDListItem -Label "Instances" -OnClick { Invoke-UDRedirect '/instances' } -Icon (New-UDIcon -Icon Database -Size 1x)
    New-UDListItem -Label "Giveaway" -OnClick { Invoke-UDRedirect '/giveaway' } -Icon (New-UDIcon -Icon Dice -Size 1x)
}

New-UDDashboard -Title 'Navigation' -Pages @(
    New-UDPage -Name 'Dashboard' -Url '/' -Content {
        New-UDTabs -Tabs {
            
            New-UDTab -Text "Overall Latency" -Content {
                $todayDate = Get-Date -Format "yyyyMMdd"
                if(Test-Path "$latencyLogsFolderPath/$todayDate.log"){
                    $dataSource = Get-Content "$latencyLogsFolderPath/$todayDate.log" | ConvertFrom-Json
                    New-UDChartJS -Id "latencychart" -Type line -Data $dataSource -DataProperty "average" -LabelProperty "time"
                }
                else {
                    New-UDTypography -Text "No data to show"
                }    
            }
            New-UDTab -Text "Live latency" -Content {
                New-UDChartJSMonitor -LoadData {
                    Test-DbaNetworkLatency -SqlInstance localhost -SqlCredential $sqlcred | Select-Object -ExpandProperty Average | Select-Object -ExpandProperty Milliseconds | Out-UDChartJSMonitorData
                } -Labels "average latency" -RefreshInterval 2 
            }
        }
        
    }

    New-UDPage -Name 'Logs' -Url '/logs' -Content {
        New-UDTabs -Tabs {
            New-UDTab -Text "View Logs" -Content {     
                New-UDHeading -Id "loganalysis" -Text "Log Analysis" -Size 1 -Color "green"
                New-UDCard -Id Dates -Content {
                    
                    New-UDDatePicker -Id "startdate" -Label "StartDate"
                    New-UDDatePicker -Id "enddate" -Label "EndDate"
                    
                    New-UDButton -Id "fetchlogsbutton" -Text "Check Logs" -OnClick {
                        $startDate = (Get-UDElement -Id 'startdate').Value.Date
                        $endDate = (Get-UDElement -Id 'enddate').Value.Date.AddDays(1)
                        #Show-UDToast -Message "startDate:$($startDateElement.Value.Date). EndDate: $($endDateElement.Value.Date)" -Duration 15000
                        $query =    "Select Id, Date, LogLevel, Class, Method, Action, RequestDuration, TraceIdentifier, Info
                                    FROM logarchive
                                    WHERE Date BETWEEN '$startDate' AND '$endDate'"
                        $Session:QUERYRESULT = Invoke-DbaQuery -SqlInstance localhost -SqlCredential $sqlcred  -database "logholder" -Query $query
                        Sync-UDElement -Id 'logstable'
                    }
                }

                New-UDDynamic -Id 'logstable' -Content {
                    if($Session:QUERYRESULT){
                        $Columns = @(
                            New-UDTableColumn -Property Date -Title Date -Truncate
                            New-UDTableColumn -Property LogLevel -Title LogLevel 
                            New-UDTableColumn -Property Class -Title Class 
                            New-UDTableColumn -Property Method -Title Method -ShowFilter -FilterType select
                            New-UDTableColumn -Property Action -Title Action -ShowFilter -FilterType select
                            New-UDTableColumn -Property RequestDuration -Title RequestDuration
                            New-UDTableColumn -Property TraceIdentifier -Title TraceIdentifier -ShowFilter -FilterType text
                            New-UDTableColumn -Property Info -Title Info -Truncate
                        )
                        New-UDTable -Data $Session:QUERYRESULT -Columns $Columns -ShowPagination -PaginationLocation Top -PageSize 20 
                        
                    }
                }    
                # } -LoadingComponent {
                #     1..5 | ForEach-Object { New-UDSkeleton -Animation 'wave' }
                # }
            }
            New-UDTab -Text "Upload logs" -Content {
                New-UDUpload -Text "Upload logs" -OnUpload {
                    $Session:CSV = Import-Csv $Body.FileName -Delimiter "|"
        
                    $paramSplat = @{
                        Path            = $Body.FileName
                        Delimiter       = '|'
                        SqlInstance     = 'Localhost'
                        SqlCredential   = $sqlcred
                        Database        = 'LogHolder'
                        Table           = 'logarchive' 
                    }
                    
                    $importOutput = Import-DbaCsv @paramSplat
                    Show-UDToast -Message "Added $($importOutput.RowsCopied) rows in $($importOutput.Elapsed)." -Duration 10000
                    #Sync-UDElement -Id "logstable"
                }
            }
        }
    } 

    New-UDPage -Name "Database Management" -Url '/management' -Content {
        $dbsToExclude = @("master", "tempdb", "model", "msdb")

        New-UDCard -Id "backupcard" -Title "Backup database" -Content {
            #New-UDDynamic -AutoRefresh -AutoRefreshInterval 5 -Content {
            New-UDSelect -Id "databasebackupselect" -Label "Database to backup" -Option {
                New-UDSelectOption -Name "n/a" -Value "n/a"
                Get-DbaDatabase -SqlInstance localhost -SqlCredential $sqlcred | Select-Object -ExpandProperty name | Where-Object { $dbsToExclude -notcontains $_ } | ForEach-Object {
                    New-UDSelectOption -Name $_ -Value $_
                }
            }
            #}
            New-UDTextbox -Id "backupname" -Label "backup file name"
            New-UDButton -Text "Backup" -OnClick {
                $databaseToBackup = (Get-UDElement -Id "databasebackupselect").Value
                $backupName = (Get-UDElement -Id "backupname").Value
                Show-UDToast -Message "Backing up $databaseToBackup to new name = $backupName" -Duration 5000
                Backup-DbaDatabase -SqlInstance localhost -SqlCredential $sqlcred -Database $databaseToBackup -Path $backupsFolderPath -FilePath "$backupName.bak"
            }
            
        }

        New-UDCard -Id "restorecard" -Title "Restore database" -Content {
            #New-UDDynamic -AutoRefresh -AutoRefreshInterval 5 -Content {
            New-UDSelect -Id "backupfileselect" -Label "Backup to restore" -Option {
                Get-ChildItem $backupFolderOnHost | Select-Object -ExpandProperty Name | ForEach-Object {
                    New-UDSelectOption -Name $_ -Value $_
                }
            }
            #}

            
            New-UDSelect -Id "restoreselect" -Label "Target Database" -Option {
                Get-DbaDatabase -SqlInstance localhost -SqlCredential $sqlcred | Select-Object -ExpandProperty name | Where-Object { $dbsToExclude -notcontains $_ } | ForEach-Object {
                    New-UDSelectOption -Name $_ -Value $_
                }
            }
            

            New-UDButton -Text "Restore" -OnClick {
                $backupFilePath = (Get-UDElement -Id backupfileselect).Value
                $targetDatabase = (Get-UDElement -Id restoreselect).Value
                $result = Restore-DbaDatabase -SqlInstance localhost -SqlCredential $sqlcred -DatabaseName $targetDatabase -Path "$backupsFolderPath/$backupFilePath" -WithReplace 
                
                Show-UDToast -Message "restore complete? ->$($result.RestoreComplete)  `n Restored backup in $backupFilePath for database $targetDatabase" -Duration 5000
            }
            
        }
        
        New-UDCard -Id "duplicatecard" -Title "Duplicate Database" -Content {           
            New-UDSelect -Id "databaseselect" -Label "Database to duplicate" -Option {
                Get-DbaDatabase -SqlInstance localhost -SqlCredential $sqlcred | Select-Object -ExpandProperty name | Where-Object { $dbsToExclude -notcontains $_ } | ForEach-Object {
                    New-UDSelectOption -Name $_ -Value $_
                }
            }

            New-UDTextbox -Id "databasenametextbox" -Label "Prefix for new database"

            New-UDButton -Text "Duplicate" -OnClick {
                $newDatabasePrefix = (Get-UDElement -Id databasenametextbox).Value
                $databaseToCopy = (Get-UDElement -Id "databaseselect").Value
                
                $result = Backup-DbaDatabase -SqlInstance localhost -SqlCredential $sqlcred -Database $databaseToCopy | Restore-DbaDatabase -SqlInstance localhost -SqlCredential $sqlcred  -RestoredDatabaseNamePrefix $newDatabasePrefix -DestinationFilePrefix $newDatabasePrefix

                Show-UDToast -Message "Duplicated $databaseToCopy to $($result.Database) in $($result.DatabaseRestoreTime)" -Duration 5000
            }
        }
        
    }

    New-UDPage -Name "Instances" -Url "/instances" -Content {
        New-UDSlider -Id "numinstances" -Minimum 1 -Maximum 10
        New-UDTextbox -Id "startingport" -Label "Starting port:"

        New-UDButton -Text "Create containers" -OnClick {
            $numberOfInstances = (Get-UDElement -Id numinstances).Value
            $startingPort = (Get-UDElement -Id startingport).Value

            1..$numberOfInstances | ForEach-Object {
                $smallGuid = (New-Guid).Guid.Split('-')[0]
                $portToUse = ([int]$startingPort)+$_-1 #advanced calculus
                Write-Host "Guid = $smallGuid port = $portTouse"
                docker run --name "burstable_sqlinstance_$smallGuid" -p "$($portToUse):1433" -d dbatools/sqlinstance
            }
        }

        New-UDDynamic -AutoRefresh -AutoRefreshInterval 5 -Content {
            New-UDList -Content {
                $burstableContainers = docker ps --format "table {{.Names}}|{{.Image}}|{{.Ports}}" | ConvertFrom-Csv -Delimiter '|' | Where-Object {$_.Names.StartsWith('burstable_sqlinstance')} | Select-Object Names, Ports 
                
                $burstableContainers | ForEach-Object {
                    $currContainerName = $_.Names
                    New-UDListItem -Label "$($_.Names); $($_.Ports.SubString($_.Ports.LastIndexOf(':')+1))" -OnClick {
                        Show-UDModal -Content {
                            New-UDTypography -Text "Do you want to delete this container?"
                            New-UDButton -Text "Confirm" -OnClick {
                                docker rm -f $currContainerName
                                Show-UDToast "Removed $currContainerName" -Duration 5000
                                Hide-UDModal
                            }
                        }
                    }
                }
            }
        }

    }

    New-UDPage -Name "Giveaway" -Url "giveaway" -Content {
        $session:answers = $null
        $session:showButton = $false
        New-UDGrid -Container -Content {
            New-UDGrid -Item -ExtraSmallSize 3 -Content {
                New-UDImage -id "qrcode" -Width 300 -Height 300 -Path '/Users/danielsilva/Documents/Presentations/psconfeu22/universaldbatools/QRCode_dbatools_giveaway.png'
                New-UDButton -Text "Get participants!" -OnClick {
                    $formId = 'DQSIkWdsW0yxEjajBLZtrQAAAAAAAAAAAAYAAPYzKdhUMVVWR1ZJQjZGSUlITjU1RU9DVUVOVk1YSi4u'
                    $uri = "https://forms.office.com/formapi/api/forms/$formId/responses"
                    $r = Invoke-RestMethod -Headers @{ cookie = $formCookie } -Uri $uri
                    $session:answers = $r.value.answers | ForEach-Object { $_ | convertfrom-json | Select-Object -first 1 -ExpandProperty answer1 }  | Where-Object { $_ } | Get-Unique 
                    #$session:answers = Invoke-RestMethod -Method GET -Uri "http://names.drycodes.com/100"
                    $session:showButton = $true
                    Sync-UDElement -Id 'participantdynamic'
                }
            }
            New-UDDynamic -Id 'participantdynamic' -Content {
                New-UDGrid -Item -ExtraSmallSize 3 -Content {    
                    New-UDList -Id 'participantslist' -Content {
                        $session:answers | ForEach-Object {
                            New-UDListItem -Label $_
                        }
                    }
                }

                New-UdGrid -Item -ExtraSmallSize 3 -Content {
                    if($session:showButton){
                        New-UDButton -Text "And the winner is..." -OnClick {
                            $session:winner = (1..10 | ForEach-Object{ $session:answers | Get-Random }) | Get-Unique | Select-Object -first 1
                            Show-UDModal -Content {
                                New-UDTypography -Text $session:winner -Variant h1
                            }
                        }
                    }
                }
            }
        }
    }

) -Navigation $navigation